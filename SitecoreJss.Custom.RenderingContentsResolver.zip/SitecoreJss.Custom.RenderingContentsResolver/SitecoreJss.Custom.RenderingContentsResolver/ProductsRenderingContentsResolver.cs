﻿using Sitecore.LayoutService.Configuration;
using Sitecore.Mvc.Presentation;

namespace SitecoreJss.Custom.RenderingContentsResolver
{
	public class ProductsRenderingContentsResolver : Sitecore.LayoutService.ItemRendering.ContentsResolvers.RenderingContentsResolver
	{
		public override object ResolveContents(Rendering rendering, IRenderingConfiguration renderingConfig)
		{
			//if you want to access the datasource item
			var datasource = !string.IsNullOrEmpty(rendering.DataSource)
				? rendering.RenderingItem?.Database.GetItem(rendering.DataSource)
				: null;
			if (datasource == null)
			{
				return null;
			}

			var jObject = base.ProcessItem(datasource, rendering, renderingConfig);

			return jObject;
		}
	}
}
