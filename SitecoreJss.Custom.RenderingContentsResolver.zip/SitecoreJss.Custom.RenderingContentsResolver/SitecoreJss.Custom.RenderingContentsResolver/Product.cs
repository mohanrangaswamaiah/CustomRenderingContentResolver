﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SitecoreJss.Custom.RenderingContentsResolver
{
	public class Product
	{
		public string heading { get; set; }
		public int ProductId { get; set; }
		public string Color { get; set; }
		public string Design { get; set; }
		public string Size { get; set; }
		public string Weight { get; set; }
		public string Price { get; set; }
	
	}
}
